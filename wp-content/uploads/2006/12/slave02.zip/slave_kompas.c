#include <90s2313.h>
//#include <stdlib.h>              
      
/*char strLCD[5];
// Alphanumeric LCD Module functions
#asm
   .equ __lcd_port=0x18; //PORTB
#endasm
#include <lcd.h>*/

// I2C Bus functions
#asm
   .equ __i2c_port=0x12; //PORTD
   .equ __sda_bit=1
   .equ __scl_bit=0
#endasm
#include <i2c.h>

// Declare your global variables here
#define compas_addr 	0xC0                             

unsigned char compas_read(unsigned char addr)
{
	unsigned char data;
	
	i2c_start();
	i2c_write(compas_addr);
	i2c_write(addr);
	i2c_start();
	i2c_write(compas_addr|1);
	data=i2c_read(0);
	i2c_stop();
	return data;
}
void main(void)
{
// Declare your local variables here

PORTB=0x00;
DDRB=0xff;


// Timer/Counter 0 initialization
// Clock source: System Clock
// Clock value: Timer 0 Stopped
TCCR0=0x00;
TCNT0=0x00;

// Timer/Counter 1 initialization
// Clock source: System Clock
// Clock value: Timer 1 Stopped
// Mode: Normal top=FFFFh
// OC1 output: Discon.
// Noise Canceler: Off
// Input Capture on Falling Edge
TCCR1A=0x00;
TCCR1B=0x00;
TCNT1H=0x00;
TCNT1L=0x00;
OCR1H=0x00;
OCR1L=0x00;

// External Interrupt(s) initialization
// INT0: Off
// INT1: Off
GIMSK=0x00;
MCUCR=0x00;

// Timer(s)/Counter(s) Interrupt(s) initialization
TIMSK=0x00;

// Analog Comparator initialization
// Analog Comparator: Off
// Analog Comparator Input Capture by Timer/Counter 1: Off
// Analog Comparator Output: Off
ACSR=0x80;

// I2C Bus initialization
i2c_init();


// LCD module initialization
//lcd_init(16);       

while (1)
      {      
            
      //lcd_gotoxy(0,0);
      //itoa(compas_read(1),strLCD);
      //lcd_puts(strLCD);  
      PORTB = compas_read(1);
      };
}
