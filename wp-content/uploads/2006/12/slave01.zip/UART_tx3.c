#include <mega8535.h>  
#include <delay.h>


interrupt [TIM0_OVF] void timer0_ovf_isr(void)
{    
	TCCR0 = 0x00;  
	TCNT0 = 0xff;      
} 

#define ping0_s DDRC.0
#define ping0_w PORTC.0
#define ping0_r PINC.0

#define ping1_s DDRC.1
#define ping1_w PORTC.1
#define ping1_r PINC.1

#define ping2_s DDRC.2
#define ping2_w PORTC.2
#define ping2_r PINC.2

#define ping3_s DDRC.3
#define ping3_w PORTC.3
#define ping3_r PINC.3

#define ping4_s DDRC.4
#define ping4_w PORTC.4
#define ping4_r PINC.4

#define ping5_s DDRC.5
#define ping5_w PORTC.5
#define ping5_r PINC.5
//unsigned char dataPing[6];

//USART Tx
#define RXB8 1
#define TXB8 0
#define UPE 2
#define OVR 3
#define FE 4
#define UDRE 5
#define RXC 7

#define FRAMING_ERROR (1<<FE)
#define PARITY_ERROR (1<<UPE)
#define DATA_OVERRUN (1<<OVR)
#define DATA_REGISTER_EMPTY (1<<UDRE)
#define RX_COMPLETE (1<<RXC)

// USART Transmitter buffer
#define TX_BUFFER_SIZE 7
char tx_buffer[TX_BUFFER_SIZE];
unsigned char tx_wr_index,tx_rd_index,tx_counter;

// USART Transmitter interrupt service routine
#pragma savereg-
interrupt [USART_TXC] void usart_tx_isr(void)
{
#asm
    push r26
    push r27
    push r30
    push r31
    in   r26,sreg
    push r26
#endasm
if (tx_counter)
   {
   --tx_counter;
   UDR=tx_buffer[tx_rd_index];
  
   if (++tx_rd_index == TX_BUFFER_SIZE) tx_rd_index=0;
   };
#asm
    pop  r26
    out  sreg,r26
    pop  r31
    pop  r30
    pop  r27
    pop  r26
#endasm
}
#pragma savereg+

#ifndef _DEBUG_TERMINAL_IO_
// Write a character to the USART Transmitter buffer
#define _ALTERNATE_PUTCHAR_
#pragma used+
void putchar(char c)
{
while (tx_counter == TX_BUFFER_SIZE);
#asm("cli")
if (tx_counter || ((UCSRA & DATA_REGISTER_EMPTY)==0))
   {
   tx_buffer[tx_wr_index]=c;
   if (++tx_wr_index == TX_BUFFER_SIZE) tx_wr_index=0;
   ++tx_counter;
   }
else
   UDR=c;
#asm("sei")
}
#pragma used-
#endif

// Standard Input/Output functions
#include <stdio.h>

// Declare your global variables here

void main(void)
{
// Declare your local variables here
tx_rd_index = 0;
// Input/Output Ports initialization
// Port A initialization
// Func0=In Func1=In Func2=In Func3=In Func4=In Func5=In Func6=In Func7=In 
// State0=T State1=T State2=T State3=T State4=T State5=T State6=T State7=T 
PORTA=0x00;
DDRA=0xff;

// Port B initialization
// Func0=In Func1=In Func2=In Func3=In Func4=In Func5=In Func6=In Func7=In 
// State0=T State1=T State2=T State3=T State4=T State5=T State6=T State7=T 
PORTB=0x00;
DDRB=0x00;

//ping
PORTC=0x00;
DDRC=0xff;

// Port D initialization
// Func0=In Func1=In Func2=In Func3=In Func4=In Func5=In Func6=In Func7=In 
// State0=T State1=T State2=T State3=T State4=T State5=T State6=T State7=T 
PORTD=0x00;
DDRD=0x00;

// Timer/Counter 0 initialization
// Clock source: System Clock
// Clock value: Timer 0 Stopped
// Mode: Normal top=FFh
// OC0 output: Disconnected
TCCR0=0x00;
TCNT0=0x00;
OCR0=0x00;

// Timer/Counter 1 initialization
// Clock source: System Clock
// Clock value: Timer 1 Stopped
// Mode: Normal top=FFFFh
// OC1A output: Discon.
// OC1B output: Discon.
// Noise Canceler: Off
// Input Capture on Falling Edge
TCCR1A=0x00;
TCCR1B=0x00;
TCNT1H=0x00;
TCNT1L=0x00;
OCR1AH=0x00;
OCR1AL=0x00;
OCR1BH=0x00;
OCR1BL=0x00;

// Timer/Counter 2 initialization
// Clock source: System Clock
// Clock value: Timer 2 Stopped
// Mode: Normal top=FFh
// OC2 output: Disconnected
ASSR=0x00;
TCCR2=0x00;
TCNT2=0x00;
OCR2=0x00;

// External Interrupt(s) initialization
// INT0: Off
// INT1: Off
// INT2: Off
MCUCR=0x00;
MCUCSR=0x00;

// Timer(s)/Counter(s) Interrupt(s) initialization
TIMSK=0x01;

// USART initialization
// Communication Parameters: 8 Data, 1 Stop, No Parity
// USART Receiver: Off
// USART Transmitter: On
// USART Mode: Asynchronous
// USART Baud rate: 9600 (Double Speed Mode)
UCSRA=0x02;
UCSRB=0x48;
UCSRC=0x86;
UBRRH=0x00;
UBRRL=0x33;

// Analog Comparator initialization
// Analog Comparator: Off
// Analog Comparator Input Capture by Timer/Counter 1: Off
// Analog Comparator Output: Off
ACSR=0x80;
SFIOR=0x00;

// Global enable interrupts
#asm("sei")


while (1)
      {      
       
    
  //ping4 
  ping4_s = 1;   //as output 
  ping4_w = 1;  //set ping 
  delay_us(3);    //delay 3 us
  ping4_w = 0;  //reset ping
  delay_us(500);  //delay 700us                             
  ping4_w = 1;  //set ping, input
  delay_us(2);    //delay 3 us
  ping4_s = 0;   //as input
  ping4_w = 0;     
  TCNT0 = 0x01;      
  while (!ping4_r) //tunggu ampe high
  ;
  TCCR0 = 0x03; //start timer 0,  clk/64 prescalling
  while (ping4_r && (TCCR0 == 0x03)) //tunggu ampe low
  ;
  TCCR0 = 0x00; //timer 0 off      
  ping4_s = 1; //as output                                                 
  ping4_w = 0; //reset ping
  //dataPing[4] = TCNT0; 
  putchar(TCNT0);  
             
   //ping0 
  ping0_s = 1;   //as output 
  ping0_w = 1;  //set ping 
  delay_us(3);    //delay 3 us
  ping0_w = 0;  //reset ping
  delay_us(500);  //delay 700us                             
  ping0_w = 1;  //set ping, input
  delay_us(2);    //delay 3 us
  ping0_s = 0;   //as input
  ping0_w = 0;        
  TCNT0 = 0x01;      
  while (!ping0_r) //tunggu ampe high
  ;
  TCCR0 = 0x03; //start timer 0,  clk/1024 prescalling
  while (ping0_r && (TCCR0 == 0x03)) //tunggu ampe low
  ;
  TCCR0 = 0x00; //timer 0 off      
  ping0_s = 1; //as output                                                 
  ping0_w = 0; //reset ping
  //dataPing[0] = TCNT0;
  putchar(TCNT0); 
  
  //ping3 
  ping3_s = 1;   //as output 
  ping3_w = 1;  //set ping 
  delay_us(3);    //delay 3 us
  ping3_w = 0;  //reset ping
  delay_us(500);  //delay 700us                             
  ping3_w = 1;  //set ping, input
  delay_us(2);    //delay 3 us
  ping3_s = 0;   //as input
  ping3_w = 0;          
  TCNT0 = 0x01;      
  while (!ping3_r) //tunggu ampe high
  ;
  TCCR0 = 0x03; //start timer 0,  clk/1024 prescalling
  while (ping3_r && (TCCR0 == 0x03)) //tunggu ampe low
  ;
  TCCR0 = 0x00; //timer 0 off      
  ping3_s = 1; //as output                                                 
  ping3_w = 0; //reset ping
  //dataPing[3] = TCNT0;
  putchar(TCNT0);       
  
  //ping1 
  ping1_s = 1;   //as output 
  ping1_w = 1;  //set ping 
  delay_us(3);    //delay 3 us
  ping1_w = 0;  //reset ping
  delay_us(500);  //delay 700us                             
  ping1_w = 1;  //set ping, input
  delay_us(2);    //delay 3 us
  ping1_s = 0;   //as input
  ping1_w = 0;        
  TCNT0 = 0x01;      
  while (!ping1_r) //tunggu ampe high
  ;
  TCCR0 = 0x03; //start timer 0,  clk/1024 prescalling
  while (ping1_r && (TCCR0 == 0x03)) //tunggu ampe low
  ;
  TCCR0 = 0x00; //timer 0 off      
  ping1_s = 1; //as output                                                 
  ping1_w = 0; //reset ping
  //dataPing[1] = TCNT0;
   putchar(TCNT0); 
   
  
  
    
 
  //ping5 
  ping5_s = 1;   //as output 
  ping5_w = 1;  //set ping 
  delay_us(3);    //delay 3 us
  ping5_w = 0;  //reset ping
  delay_us(500);  //delay 700us                             
  ping5_w = 1;  //set ping, input
  delay_us(2);    //delay 3 us
  ping5_s = 0;   //as input
  ping5_w = 0;       
  TCNT0 = 0x01;      
  while (!ping5_r) //tunggu ampe high
  ;
  TCCR0 = 0x03; //start timer 0,  clk/1024 prescalling
  while (ping5_r && (TCCR0 == 0x03)) //tunggu ampe low
  ;
  TCCR0 = 0x00; //timer 0 off      
  ping5_s = 1; //as output                                                 
  ping5_w = 0; //reset ping
  //dataPing[5] = TCNT0; 
  putchar(TCNT0); 
                     
  //ping2 
  ping2_s = 1;   //as output 
  ping2_w = 1;  //set ping 
  delay_us(3);    //delay 3 us
  ping2_w = 0;  //reset ping
  delay_us(500);  //delay 700us                             
  ping2_w = 1;  //set ping, input
  delay_us(2);    //delay 3 us
  ping2_s = 0;   //as input
  ping2_w = 0;        
  TCNT0 = 0x01;      
  while (!ping2_r) //tunggu ampe high
  ;
  TCCR0 = 0x03; //start timer 0,  clk/1024 prescalling
  while (ping2_r && (TCCR0 == 0x03)) //tunggu ampe low
  ;
  TCCR0 = 0x00; //timer 0 off      
  ping2_s = 1; //as output                                                 
  ping2_w = 0; //reset ping
  //dataPing[2] = TCNT0;
  putchar(TCNT0);        
  putchar(0x00);

  //PORTA = compas_read(1); 
 
 };
}
